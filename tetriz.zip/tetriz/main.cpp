#include"GL\glut.h"
#include "juego.h"
int main (int argc, char* args[])
{

    glutInit(&argc,args);

    juego partida1;


    glutMainLoop();

    return 0;

}
